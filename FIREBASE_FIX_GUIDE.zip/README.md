# Pharma Certificate Manager

A full-stack Next.js 14 web application for managing client certificates for a 3rd party pharma manufacturing company.

## Features

- ✅ Secure admin authentication using Firebase Auth
- ✅ Add new clients with contact information
- ✅ Upload multiple certificates per client:
  - Drug License Certificate
  - GST Certificate
  - Agreement Certificate
  - Other documents (PDF, Image, DOC)
- ✅ Drag-and-drop file upload with progress indicator
- ✅ Preview and download certificates
- ✅ Delete or update certificates
- ✅ Search and filter clients
- ✅ Dashboard with overview statistics
- ✅ Responsive design with professional UI
- ✅ Toast notifications for user feedback
- ✅ Smooth animations with Framer Motion

## Tech Stack

- **Next.js 14** (App Router)
- **React 18**
- **Firebase** (Authentication, Firestore, Storage)
- **Tailwind CSS** (Styling)
- **React Hot Toast** (Notifications)
- **Framer Motion** (Animations)
- **Lucide React** (Icons)

## Getting Started

### Prerequisites

- Node.js 18+ installed
- Firebase project set up

### Installation

1. Clone the repository:
```bash
git clone <repository-url>
cd "Angia Certificate upload"
```

2. Install dependencies:
```bash
npm install
```

3. Set up Firebase:

   - Create a Firebase project at [Firebase Console](https://console.firebase.google.com/)
   - Enable Authentication (Email/Password)
   - Create a Firestore database
   - Set up Firebase Storage
   - Copy your Firebase configuration

4. Create `.env.local` file in the root directory:
```env
NEXT_PUBLIC_FIREBASE_API_KEY=your_api_key_here
NEXT_PUBLIC_FIREBASE_AUTH_DOMAIN=your_project_id.firebaseapp.com
NEXT_PUBLIC_FIREBASE_PROJECT_ID=your_project_id
NEXT_PUBLIC_FIREBASE_STORAGE_BUCKET=your_project_id.appspot.com
NEXT_PUBLIC_FIREBASE_MESSAGING_SENDER_ID=your_messaging_sender_id
NEXT_PUBLIC_FIREBASE_APP_ID=your_app_id
```

5. Set up Firebase Security Rules:

   **Firestore Rules:**
   ```javascript
   rules_version = '2';
   service cloud.firestore {
     match /databases/{database}/documents {
       match /clients/{clientId} {
         allow read, write: if request.auth != null;
       }
     }
   }
   ```

   **Storage Rules:**
   ```javascript
   rules_version = '2';
   service firebase.storage {
     match /b/{bucket}/o {
       match /certificates/{allPaths=**} {
         allow read, write: if request.auth != null;
       }
     }
   }
   ```

6. Create an admin user in Firebase Authentication:
   - Go to Firebase Console > Authentication
   - Add a user with email and password
   - This will be your admin login

7. Run the development server:
```bash
npm run dev
```

8. Open [http://localhost:3000](http://localhost:3000) in your browser

## Project Structure

```
├── app/
│   ├── dashboard/
│   │   ├── add-client/       # Add new client page
│   │   ├── clients/          # View clients page
│   │   │   └── [id]/
│   │   │       └── edit/     # Edit client page
│   │   ├── layout.js         # Dashboard layout
│   │   └── page.js           # Dashboard overview
│   ├── login/                # Login page
│   ├── layout.js             # Root layout
│   ├── globals.css           # Global styles
│   └── page.js               # Home page (redirects to login)
├── components/
│   ├── CertificateCard.js    # Certificate display component
│   ├── DashboardLayout.js    # Dashboard wrapper
│   ├── FileUpload.js         # File upload component
│   ├── ProtectedRoute.js     # Auth protection
│   └── Sidebar.js            # Navigation sidebar
├── contexts/
│   └── AuthContext.js        # Authentication context
├── lib/
│   └── firebase.js           # Firebase configuration
└── package.json
```

## Usage

1. **Login**: Use your Firebase admin credentials to log in
2. **Dashboard**: View overview statistics (total clients and certificates)
3. **Add Client**: Fill in client information and upload certificates
4. **View Clients**: Browse all clients, search/filter, and manage certificates
5. **Edit Client**: Update client information and add/remove certificates
6. **Certificates**: Preview, download, or delete certificates for each client

## Features in Detail

### File Upload
- Supports PDF, Images (JPG, PNG, GIF), and DOC files
- Maximum file size: 10MB
- Drag-and-drop interface
- Real-time upload progress
- Multiple files per certificate type

### Search & Filter
- Search clients by name, contact person, or email
- Real-time filtering as you type

### Certificate Management
- View all certificates for each client
- Expandable certificate sections
- Preview certificates in new tab
- Download certificates
- Delete certificates (removes from both Firestore and Storage)

## Security

- All routes are protected with authentication
- Only authenticated users can access the dashboard
- Firebase Security Rules ensure data protection
- File uploads are validated for type and size

## Deployment

1. Build the application:
```bash
npm run build
```

2. Deploy to Vercel, Netlify, or your preferred hosting platform

3. Make sure to set environment variables in your hosting platform

## License

This project is private and proprietary.

## Support

For issues or questions, please contact the development team.

